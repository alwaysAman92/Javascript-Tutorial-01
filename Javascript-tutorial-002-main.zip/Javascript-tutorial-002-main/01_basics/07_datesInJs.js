//Dates
//TC39 or technical committee 39 is working upon temporal objects which will be more efficient

//let myDate=new Date();
//console.log(myDate.toDateString());
//console.log(myDate.toLocaleString());

//let myCreatedDate=new Date(2024,4,24) //(year,month,date)
//console.log(myCreatedDate.toDateString());

//console.log(Math.floor(Date.now()/1000));
