/*console.log(2>1);
console.log(2>=1);
console.log(2<1);
console.log(2==1);
console.log(2!=1);*/
console.log(null>=0);  
console.log(null===0);
//both the operator works differently i.e equality and comparison
//operator comparison operator converts null to zero and check the condition
console.log(undefined>=0);  
console.log(undefined==0);
//but undefined gives false always
//=== doesn't convert any datatype