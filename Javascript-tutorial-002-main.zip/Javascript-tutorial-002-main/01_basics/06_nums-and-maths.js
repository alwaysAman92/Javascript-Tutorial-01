/*const score=400
console.log(score);
const balance=new Number(100)
console.log(balance);
console.log(balance.toFixed(2));//can be used in e-commerce website to limit the decimal places of digits
const otherNumber=123.8966
console.log(otherNumber.toPrecision(3));

const Hunderds=10000000
console.log(Hunderds.toLocaleString('en-IN'));*/

//******************Maths*******************
console.log(Math);
console.log(Math.abs(-4));
console.log(Math.round(4.6));
console.log(Math.random());//gives value between 0 and 1
console.log((Math.random()*10) + 1);//gives value between 1 and 9

const min=10
const max=20

//(Math.floor(Math.random()*(max-min+1)) + min)
